import time
from main import get_7coords

print("4 秒后截图，请切回游戏画面...")
time.sleep(4)

coords = get_7coords()

if coords is False:
    print("识别失败")
else:
    pos_x, pos_y, pos_z, pos_w, face_x, face_z, face_w = coords
    print("识别成功：", coords)
